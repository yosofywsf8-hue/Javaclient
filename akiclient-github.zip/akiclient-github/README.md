# AKICLIENT

> Fabric visual client mod for Minecraft 1.21.4

---

## Features

### Visuals
| Module | Description |
|---|---|
| Custom Sky | Recolors the sky with adjustable hue & brightness |
| Screen Glow | Accent-colored glow on screen edges |
| Ambient Particles | Floating stars, cherry blossoms, snowflakes or end rods |
| Hit Particles | Burst particles when you hit a player (Crystal, X, Hearts, Crit…) |
| Hit Flash | Screen flash on hit with adjustable intensity |
| Hit Marker | Diagonal X at crosshair on hit |

### Interface
| Module | Description |
|---|---|
| Info Bar | Clock, ping, FPS, CPU usage |
| Coordinates | Live XYZ display |
| Effects HUD | Active potion effects with timers |
| Keystrokes | WASD display |
| Armor HUD | Currently worn armor |
| Target HUD | Name + health bar of your target |
| Watermark | Client name in top-right corner |

### Client
| Module | Description |
|---|---|
| Accent Color | 5 presets (Blue, Pink, Purple, Mint, Custom) + Rainbow |
| Modern Font | Smooth TTF font in the ClickGUI |

---

## ClickGUI

Press **Right Shift** to open the GUI.

- **Left click** a module → toggle on/off
- **Right click** a module → expand/collapse settings
- **Left click** mode setting → cycle forward
- **Right click** mode setting → cycle backward
- **Drag** sliders to adjust values
- **Scroll** to navigate panels

---

## Requirements

- Minecraft `1.21.4`
- Fabric Loader `>=0.16.0`
- Fabric API `0.119.2+1.21.4`
- Java `21`

---

## Build

```bash
git clone https://github.com/YOUR_USERNAME/akiclient.git
cd akiclient
./gradlew build
```

Output jar → `build/libs/akiclient-0.4.0.jar`

Drop into `.minecraft/mods/`

---

## Project Structure

```
akiclient/
├── src/main/java/com/example/pinkclient/
│   ├── PinkMain.java           — server entrypoint (particle registry)
│   ├── PinkClient.java         — client entrypoint (keybinds, events)
│   ├── Module.java             — module base class
│   ├── ModuleManager.java      — all modules + accent color logic
│   ├── Category.java           — VISUALS / INTERFACE / CLIENT
│   ├── Setting.java            — Slider + Mode settings
│   ├── Config.java             — save/load .properties
│   ├── Hud.java                — HUD rendering + color utils
│   ├── ClickGuiScreen.java     — the GUI screen
│   ├── ParticleRegistry.java   — custom particle types
│   └── mixin/
│       └── ClientWorldMixin.java — sky color override
├── src/main/resources/
│   ├── fabric.mod.json
│   ├── pinkclient.mixins.json
│   └── assets/pinkclient/
│       ├── font/               — custom TTF font
│       ├── lang/               — en_us.json
│       ├── particles/          — particle JSON definitions
│       └── textures/particle/  — particle textures
├── build.gradle
├── gradle.properties
└── settings.gradle
```

---

## Config

Settings are saved automatically when closing the GUI.

Config file location: `.minecraft/config/pinkclient-v3.properties`

---

*Built with Fabric API · Minecraft 1.21.4 · Java 21*
