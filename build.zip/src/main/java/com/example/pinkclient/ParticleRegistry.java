package com.example.pinkclient;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ParticleRegistry {
    public static SimpleParticleType CRYSTAL, XMARK, STAR;

    public static void register() {
        CRYSTAL = Registry.register(Registries.PARTICLE_TYPE, Identifier.of("pinkclient", "crystal"), FabricParticleTypes.simple());
        XMARK   = Registry.register(Registries.PARTICLE_TYPE, Identifier.of("pinkclient", "xmark"),   FabricParticleTypes.simple());
        STAR    = Registry.register(Registries.PARTICLE_TYPE, Identifier.of("pinkclient", "star"),    FabricParticleTypes.simple());
    }
}
