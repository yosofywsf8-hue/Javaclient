package com.example.pinkclient;

public enum Category {
    VISUALS("Visuals"), INTERFACE("Interface"), CLIENT("Client");
    public final String label;
    Category(String label) { this.label = label; }
}
