package com.example.pinkclient;

public enum Category {
    HUD("HUD"), WORLD("World"), COMBAT("Hit Effects"), THEME("Theme");
    public final String label;
    Category(String label) { this.label = label; }
}
