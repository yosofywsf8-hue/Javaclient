package com.example.pinkclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.lang.management.ManagementFactory;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class PinkClient implements ClientModInitializer {
    private static KeyBinding guiKey;
    private static final int PINK = 0xFFFF69B4;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    @Override
    public void onInitializeClient() {
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pinkclient.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.pinkclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
        });

        HudRenderCallback.EVENT.register(PinkClient::renderHud);
    }

    private static void renderHud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        if (ModuleManager.GLOW.enabled) {
            ctx.fillGradient(0, 0, w, h / 4, 0x66FF69B4, 0x00FF69B4);
            ctx.fillGradient(0, h - h / 4, w, h, 0x00FF69B4, 0x66FF1493);
        }

        if (ModuleManager.INFO_BAR.enabled) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            double cpu = 0;
            if (ManagementFactory.getOperatingSystemMXBean()
                    instanceof com.sun.management.OperatingSystemMXBean os) {
                cpu = Math.max(0, os.getCpuLoad()) * 100;
            }
            String text = LocalTime.now().format(TIME)
                    + "  |  " + ping + " MS"
                    + "  |  " + mc.getCurrentFps() + " FPS"
                    + "  |  " + (int) cpu + "% CPU";
            int tw = mc.textRenderer.getWidth(text);
            ctx.fill(2, 2, tw + 12, 16, 0xAA1A0A14);
            ctx.fill(2, 2, 4, 16, PINK);
            ctx.drawText(mc.textRenderer, text, 8, 6, 0xFFFFFFFF, true);
        }

        if (ModuleManager.FPS_BIG.enabled) {
            String fps = "FPS: " + mc.getCurrentFps();
            ctx.drawCenteredTextWithShadow(mc.textRenderer, fps, w / 2, 4, PINK);
        }

        if (ModuleManager.WATERMARK.enabled) {
            ctx.drawText(mc.textRenderer, "Pink Client 0.1", w - 90, 6, PINK, true);
        }
    }
}
