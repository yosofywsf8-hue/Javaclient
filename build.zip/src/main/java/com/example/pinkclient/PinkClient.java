package com.example.pinkclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;

public class PinkClient implements ClientModInitializer {
    public static volatile long lastHit = 0;
    public static volatile LivingEntity lastTarget = null;

    private static KeyBinding guiKey;
    private static int tickCount = 0;

    @Override
    public void onInitializeClient() {
        Config.load();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pinkclient.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.pinkclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            tickCount++;
            if (ModuleManager.PARTICLES.enabled && client.world != null && client.player != null) {
                int every = Math.max(1, 11 - ModuleManager.P_DENSITY.getInt());
                if (tickCount % every == 0) spawnAmbient(client);
            }
        });

        HudRenderCallback.EVENT.register(Hud::render);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player && entity instanceof PlayerEntity target) {
                lastHit = System.currentTimeMillis();
                lastTarget = target;
                if (ModuleManager.HIT_PARTICLES.enabled) spawnHit(world, target);
            }
            return ActionResult.PASS;
        });
    }

    private static void spawnAmbient(MinecraftClient mc) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        ParticleEffect type = ModuleManager.P_TYPE.index == 0 ? ParticleTypes.CHERRY_LEAVES : ParticleTypes.END_ROD;
        for (int i = 0; i < 2; i++) {
            double x = mc.player.getX() + r.nextDouble(-10, 10);
            double y = mc.player.getY() + r.nextDouble(0, 6);
            double z = mc.player.getZ() + r.nextDouble(-10, 10);
            mc.world.addParticle(type, x, y, z, 0, -0.02, 0);
        }
    }

    private static void spawnHit(net.minecraft.world.World world, PlayerEntity target) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        ParticleEffect type = switch (ModuleManager.H_TYPE.index) {
            case 0 -> ParticleTypes.HEART;
            case 1 -> ParticleTypes.CRIT;
            case 2 -> ParticleTypes.END_ROD;
            case 3 -> ParticleTypes.CHERRY_LEAVES;
            default -> ParticleTypes.TOTEM_OF_UNDYING;
        };
        int n = ModuleManager.H_AMOUNT.getInt();
        for (int i = 0; i < n; i++) {
            world.addParticle(type,
                    target.getX() + r.nextDouble(-0.4, 0.4),
                    target.getY() + r.nextDouble(0.2, target.getHeight()),
                    target.getZ() + r.nextDouble(-0.4, 0.4),
                    r.nextDouble(-0.25, 0.25), r.nextDouble(0.0, 0.25), r.nextDouble(-0.25, 0.25));
        }
    }
}
