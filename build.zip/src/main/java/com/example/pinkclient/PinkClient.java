package com.example.pinkclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.particle.EndRodParticle;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;

public class PinkClient implements ClientModInitializer {
    public static volatile long lastHit = 0;
    public static volatile LivingEntity lastTarget = null;

    private static KeyBinding guiKey;
    private static int tickCount = 0;

    @Override
    public void onInitializeClient() {
        Config.load();

        ParticleFactoryRegistry reg = ParticleFactoryRegistry.getInstance();
        reg.register(ParticleRegistry.CRYSTAL, EndRodParticle.Factory::new);
        reg.register(ParticleRegistry.XMARK, EndRodParticle.Factory::new);
        reg.register(ParticleRegistry.STAR, EndRodParticle.Factory::new);

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pinkclient.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.pinkclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            tickCount++;
            if (ModuleManager.PARTICLES.enabled && client.world != null && client.player != null) {
                int every = Math.max(1, 11 - ModuleManager.P_DENSITY.getInt());
                if (tickCount % every == 0) spawnAmbient(client);
            }
        });

        HudRenderCallback.EVENT.register(Hud::render);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player && entity instanceof PlayerEntity target) {
                lastHit = System.currentTimeMillis();
                lastTarget = target;
                if (ModuleManager.HIT_PARTICLES.enabled) spawnHit(world, target);
            }
            return ActionResult.PASS;
        });
    }

    private static void spawnAmbient(MinecraftClient mc) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        ParticleEffect type = switch (ModuleManager.P_TYPE.index) {
            case 0 -> ParticleRegistry.STAR;
            case 1 -> ParticleTypes.CHERRY_LEAVES;
            case 2 -> ParticleTypes.SNOWFLAKE;
            default -> ParticleTypes.END_ROD;
        };
        for (int i = 0; i < 2; i++) {
            double x = mc.player.getX() + r.nextDouble(-10, 10);
            double y = mc.player.getY() + r.nextDouble(0, 6);
            double z = mc.player.getZ() + r.nextDouble(-10, 10);
            mc.world.addParticle(type, x, y, z, r.nextDouble(-0.01, 0.01), 0.005, r.nextDouble(-0.01, 0.01));
        }
    }

    private static void burst(World world, PlayerEntity t, ParticleEffect type, int n, double speed) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < n; i++) {
            world.addParticle(type,
                    t.getX() + r.nextDouble(-0.4, 0.4),
                    t.getY() + r.nextDouble(0.2, t.getHeight()),
                    t.getZ() + r.nextDouble(-0.4, 0.4),
                    r.nextDouble(-speed, speed), r.nextDouble(0.0, speed), r.nextDouble(-speed, speed));
        }
    }

    private static void spawnHit(World world, PlayerEntity t) {
        int n = ModuleManager.H_AMOUNT.getInt();
        switch (ModuleManager.H_TYPE.index) {
            case 0 -> { burst(world, t, ParticleRegistry.CRYSTAL, n, 0.22); burst(world, t, ParticleRegistry.XMARK, Math.max(2, n / 2), 0.12); }
            case 1 -> burst(world, t, ParticleRegistry.CRYSTAL, n, 0.22);
            case 2 -> burst(world, t, ParticleRegistry.XMARK, n, 0.15);
            case 3 -> burst(world, t, ParticleTypes.HEART, n, 0.2);
            case 4 -> burst(world, t, ParticleTypes.CRIT, n, 0.25);
            default -> burst(world, t, ParticleTypes.ELECTRIC_SPARK, n, 0.25);
        }
    }
}
