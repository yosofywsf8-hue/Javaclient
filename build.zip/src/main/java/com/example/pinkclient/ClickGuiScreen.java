package com.example.pinkclient;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int ROW = 15, SLIDER_H = 19, MODE_H = 14, HEADER = 20, GAP = 8;
    private static final Category[] CATS = Category.values();

    private final float[] scroll = new float[3], target = new float[3];
    private final int[] total = new int[3];
    private float openAnim;

    private record Hit(int x, int y, int w, int h, int panel, Module module, Setting setting) {}
    private final List<Hit> hits = new ArrayList<>();
    private Setting.Slider dragging;
    private int dragX, dragW;

    public ClickGuiScreen() { super(Text.literal("Pink Client")); }

    // ---------- geometry ----------
    private int panelW() { return Math.max(70, Math.min(116, (width - 24 - GAP * 2) / 3)); }
    private int panelH() { return Math.min(176, height - 36); }
    private int px(int i) { return (width - (panelW() * 3 + GAP * 2)) / 2 + i * (panelW() + GAP); }
    private int py() { return (height - panelH()) / 2 + (int) ((1f - openAnim) * 14); }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        openAnim += (1f - openAnim) * 0.2f;
        int acc = ModuleManager.accent();
        ctx.fill(0, 0, width, height, Hud.alpha(0x000000, (int) (0x55 * openAnim)));
        hits.clear();

        int pw = panelW(), ph = panelH(), y0 = py();
        for (int i = 0; i < CATS.length; i++) {
            int x0 = px(i);
            Hud.round(ctx, x0, y0, x0 + pw, y0 + ph, 0xE60E1018);
            ctx.drawText(tr, CATS[i].label, x0 + 8, y0 + 7, 0xFFFFFFFF, true);
            ctx.fill(x0 + 6, y0 + HEADER - 3, x0 + pw - 6, y0 + HEADER - 2, Hud.alpha(acc, 0x80));

            int cx = x0 + 4, cy = y0 + HEADER, cw = pw - 8, ch = ph - HEADER - 4;
            float maxScroll = Math.max(0, total[i] - ch);
            target[i] = Math.max(0, Math.min(maxScroll, target[i]));
            scroll[i] += (target[i] - scroll[i]) * 0.3f;

            ctx.enableScissor(cx, cy, cx + cw, cy + ch);
            int y = cy - Math.round(scroll[i]);
            int used = 0;
            for (Module m : ModuleManager.in(CATS[i])) {
                m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
                boolean hov = mx >= cx && mx < cx + cw && my >= y && my < y + ROW && my >= cy && my < cy + ch;
                if (hov) Hud.round(ctx, cx, y, cx + cw, y + ROW, 0x24FFFFFF);

                // checkbox
                int bx = cx + 3, by = y + 3;
                ctx.fill(bx, by, bx + 9, by + 9, Hud.lerp(0xFF2A2C3A, acc, m.anim));
                if (m.anim > 0.5f) {
                    int[][] chk = {{1,4},{2,5},{3,6},{4,5},{5,4},{6,3},{7,2}};
                    for (int[] c : chk) ctx.fill(bx + c[0], by + c[1], bx + c[0] + 1, by + c[1] + 1, 0xFFFFFFFF);
                }
                ctx.drawText(tr, m.name, cx + 16, y + 4, m.enabled || !m.toggleable ? 0xFFFFFFFF : 0xFF8C90A4, false);
                if (!m.settings.isEmpty()) {
                    ctx.drawText(tr, m.expanded ? "v" : ">", cx + cw - 9, y + 4, 0xFF8C90A4, false);
                }
                hits.add(new Hit(cx, y, cw, ROW, i, m, null));
                y += ROW; used += ROW;

                if (m.expanded) {
                    for (Setting s : m.settings) {
                        if (s instanceof Setting.Slider sl) {
                            ctx.fill(cx + 3, y, cx + cw, y + SLIDER_H, 0x40000000);
                            ctx.drawText(tr, sl.name, cx + 8, y + 3, 0xFFB6BACD, false);
                            String v = sl.display();
                            ctx.drawText(tr, v, cx + cw - 5 - tr.getWidth(v), y + 3, 0xFFFFFFFF, false);
                            int tx = cx + 8, tw = cw - 16, ty = y + 14;
                            ctx.fill(tx, ty, tx + tw, ty + 3, 0xFF2A2C3A);
                            float t = (float) ((sl.value - sl.min) / (sl.max - sl.min));
                            ctx.fill(tx, ty, tx + (int) (tw * t), ty + 3, acc);
                            int kx = tx + (int) (tw * t);
                            ctx.fill(kx - 1, ty - 2, kx + 2, ty + 5, 0xFFFFFFFF);
                            hits.add(new Hit(cx + 3, y, cw - 3, SLIDER_H, i, m, sl));
                            y += SLIDER_H; used += SLIDER_H;
                        } else if (s instanceof Setting.Mode md) {
                            ctx.fill(cx + 3, y, cx + cw, y + MODE_H, 0x40000000);
                            ctx.drawText(tr, md.name, cx + 8, y + 3, 0xFFB6BACD, false);
                            String v = md.get();
                            ctx.drawText(tr, v, cx + cw - 5 - tr.getWidth(v), y + 3, acc, false);
                            hits.add(new Hit(cx + 3, y, cw - 3, MODE_H, i, m, md));
                            y += MODE_H; used += MODE_H;
                        }
                    }
                    y += 2; used += 2;
                }
            }
            ctx.disableScissor();
            total[i] = used;

            if (maxScroll > 0) {
                int barH = Math.max(12, (int) (ch * (ch / (float) total[i])));
                int barY = cy + (int) ((ch - barH) * (scroll[i] / maxScroll));
                ctx.fill(x0 + pw - 3, barY, x0 + pw - 2, barY + barH, Hud.alpha(acc, 0xAA));
            }
        }

        String hint = "Click = on/off   |   Right click = settings   |   Right Shift = close";
        ctx.drawCenteredTextWithShadow(tr, hint, width / 2, y0 + ph + 5, 0xFF8C90A4);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int pw = panelW(), ph = panelH(), y0 = py();
        for (Hit h : hits) {
            int x0 = px(h.panel);
            // ignore hits outside the visible content area of their panel
            if (my < y0 + HEADER || my >= y0 + ph - 4 || mx < x0 + 4 || mx >= x0 + pw - 4) continue;
            if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;

            if (h.setting == null) {
                if (button == 0) h.module.toggle();
                else if (button == 1 && !h.module.settings.isEmpty()) h.module.expanded = !h.module.expanded;
            } else if (h.setting instanceof Setting.Slider sl) {
                if (button == 0) {
                    dragging = sl; dragX = h.x + 5; dragW = h.w - 13;
                    updateSlider(mx);
                }
            } else if (h.setting instanceof Setting.Mode md) {
                md.next(button == 0);
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void updateSlider(double mx) {
        if (dragging == null) return;
        double t = Math.max(0, Math.min(1, (mx - dragX) / dragW));
        dragging.set(dragging.min + t * (dragging.max - dragging.min));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        for (int i = 0; i < CATS.length; i++) {
            if (mx >= px(i) && mx < px(i) + panelW()) { target[i] -= (float) (v * 20); break; }
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Config.save(); }

    @Override
    public boolean shouldPause() { return false; }
}
