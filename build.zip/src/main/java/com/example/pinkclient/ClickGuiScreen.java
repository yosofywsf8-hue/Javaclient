package com.example.pinkclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 130, ROW_H = 18, HEADER_H = 20;
    private static final int PINK = 0xFFFF69B4;

    public ClickGuiScreen() { super(Text.literal("ClickGUI")); }

    private int panelX() { return width / 2 - PANEL_W / 2; }
    private int panelY() { return height / 2 - (HEADER_H + ModuleManager.ALL.size() * ROW_H) / 2; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);

        int x = panelX(), y = panelY();
        int totalH = HEADER_H + ModuleManager.ALL.size() * ROW_H;
        ctx.fill(x, y, x + PANEL_W, y + totalH, 0xEE1A0A14);
        ctx.fill(x, y, x + PANEL_W, y + HEADER_H, PINK);
        ctx.drawCenteredTextWithShadow(textRenderer, "Visuals", x + PANEL_W / 2, y + 6, 0xFFFFFFFF);

        int ry = y + HEADER_H;
        for (Module m : ModuleManager.ALL) {
            boolean hover = mouseX >= x && mouseX < x + PANEL_W && mouseY >= ry && mouseY < ry + ROW_H;
            if (hover) ctx.fill(x, ry, x + PANEL_W, ry + ROW_H, 0x33FFFFFF);
            if (m.enabled) ctx.fill(x, ry, x + 2, ry + ROW_H, PINK);
            ctx.drawText(textRenderer, m.name, x + 8, ry + 5, m.enabled ? PINK : 0xFFAAAAAA, true);
            ry += ROW_H;
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = panelX(), ry = panelY() + HEADER_H;
        for (Module m : ModuleManager.ALL) {
            if (mx >= x && mx < x + PANEL_W && my >= ry && my < ry + ROW_H) {
                if (button == 0) m.toggle();
                return true;
            }
            ry += ROW_H;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
