package com.example.pinkclient;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int SIDE = 80, ROW = 26, SLIDER_H = 22, MODE_H = 17;
    private static Category lastTab = Category.HUD;

    private Category tab = lastTab;
    private float scroll, targetScroll, openAnim;
    private int contentTotal;
    private int cx, cy, cw, ch;

    private record Hit(int x, int y, int w, int h, Module module, Setting setting) {}
    private final List<Hit> hits = new ArrayList<>();
    private Setting.Slider dragging;
    private int dragX, dragW;

    public ClickGuiScreen() { super(Text.literal("Pink Client")); }

    // ---------- geometry ----------
    private int winW() { return Math.min(350, width - 16); }
    private int winH() { return Math.min(215, height - 16); }
    private int winX() { return (width - winW()) / 2; }
    private int winY() { return (height - winH()) / 2 + (int) ((1f - openAnim) * 14); }
    private int[] tabRect(int i) { return new int[]{ winX() + 6, winY() + 36 + i * 22, SIDE - 12, 18 }; }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        openAnim += (1f - openAnim) * 0.2f;
        int acc = ModuleManager.accent();
        int wx = winX(), wy = winY(), ww = winW(), wh = winH();

        ctx.fill(0, 0, width, height, Hud.alpha(0x000000, (int) (0x66 * openAnim)));
        Hud.round(ctx, wx, wy, wx + ww, wy + wh, 0xF2120A16);
        Hud.round(ctx, wx, wy, wx + SIDE, wy + wh, 0xF20B0610);
        ctx.fill(wx + 2, wy, wx + ww - 2, wy + 2, acc);

        // title
        ctx.drawText(tr, "Pink", wx + 10, wy + 10, acc, true);
        ctx.drawText(tr, "Client", wx + 10 + tr.getWidth("Pink "), wy + 10, 0xFFFFFFFF, true);
        ctx.drawText(tr, "visuals", wx + 10, wy + 21, 0xFF7A687F, false);

        // tabs
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int[] r = tabRect(i);
            boolean sel = cats[i] == tab;
            boolean hov = mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3];
            if (sel) {
                Hud.round(ctx, r[0], r[1], r[0] + r[2], r[1] + r[3], Hud.alpha(acc, 0x45));
                ctx.fill(r[0], r[1] + 2, r[0] + 2, r[1] + r[3] - 2, acc);
            } else if (hov) {
                Hud.round(ctx, r[0], r[1], r[0] + r[2], r[1] + r[3], 0x22FFFFFF);
            }
            ctx.drawText(tr, cats[i].label, r[0] + 9, r[1] + 5, sel ? 0xFFFFFFFF : 0xFF9A8AA0, sel);
        }

        // content frame
        cx = wx + SIDE + 8; cy = wy + 30; cw = ww - SIDE - 16; ch = wh - 38;
        ctx.drawText(tr, tab.label, cx, wy + 10, 0xFFFFFFFF, true);
        String hint = "Right click = settings";
        ctx.drawText(tr, hint, cx + cw - tr.getWidth(hint), wy + 10, 0xFF6F5E75, false);

        // modules
        hits.clear();
        float maxScroll = Math.max(0, contentTotal - ch);
        targetScroll = Math.max(0, Math.min(maxScroll, targetScroll));
        scroll += (targetScroll - scroll) * 0.3f;

        ctx.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        int y = cy - Math.round(scroll);
        int total = 0;
        for (Module m : ModuleManager.in(tab)) {
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
            boolean hov = mx >= cx && mx < cx + cw && my >= y && my < y + ROW - 2 && my >= cy && my < cy + ch;
            Hud.round(ctx, cx, y, cx + cw, y + ROW - 2, hov ? 0xFF2C1A33 : 0xFF1E1224);
            if (m.enabled) ctx.fill(cx, y + 2, cx + 2, y + ROW - 4, acc);
            ctx.drawText(tr, m.name, cx + 8, y + 4, 0xFFFFFFFF, true);
            ctx.drawText(tr, m.desc, cx + 8, y + 14, 0xFF8A7890, false);

            if (!m.settings.isEmpty()) {
                ctx.drawText(tr, m.expanded ? "v" : ">", cx + cw - 44, y + 8, 0xFF9A8AA0, false);
            }
            if (m.toggleable) {
                int tx = cx + cw - 30, ty = y + 7;
                Hud.round(ctx, tx, ty, tx + 22, ty + 10, Hud.lerp(0xFF3A2A40, acc, m.anim));
                int kx = tx + 1 + (int) (m.anim * 12);
                ctx.fill(kx, ty + 1, kx + 8, ty + 9, 0xFFFFFFFF);
            }
            hits.add(new Hit(cx, y, cw, ROW - 2, m, null));
            y += ROW; total += ROW;

            if (m.expanded) {
                for (Setting s : m.settings) {
                    if (s instanceof Setting.Slider sl) {
                        Hud.round(ctx, cx + 6, y - 2, cx + cw, y + SLIDER_H - 3, 0xFF160C1B);
                        ctx.drawText(tr, sl.name, cx + 12, y + 2, 0xFFCDBFD2, false);
                        String v = sl.display();
                        ctx.drawText(tr, v, cx + cw - 6 - tr.getWidth(v), y + 2, 0xFFFFFFFF, false);
                        int tx = cx + 12, tw = cw - 22, ty = y + 12;
                        ctx.fill(tx, ty, tx + tw, ty + 3, 0xFF3A2640);
                        float t = (float) ((sl.value - sl.min) / (sl.max - sl.min));
                        ctx.fill(tx, ty, tx + (int) (tw * t), ty + 3, acc);
                        int kx = tx + (int) (tw * t);
                        ctx.fill(kx - 1, ty - 2, kx + 2, ty + 5, 0xFFFFFFFF);
                        hits.add(new Hit(cx + 6, y - 2, cw - 6, SLIDER_H - 1, m, sl));
                        y += SLIDER_H; total += SLIDER_H;
                    } else if (s instanceof Setting.Mode md) {
                        Hud.round(ctx, cx + 6, y - 2, cx + cw, y + MODE_H - 3, 0xFF160C1B);
                        ctx.drawText(tr, md.name, cx + 12, y + 2, 0xFFCDBFD2, false);
                        String v = "< " + md.get() + " >";
                        ctx.drawText(tr, v, cx + cw - 6 - tr.getWidth(v), y + 2, acc, false);
                        hits.add(new Hit(cx + 6, y - 2, cw - 6, MODE_H - 1, m, md));
                        y += MODE_H; total += MODE_H;
                    }
                }
                y += 3; total += 3;
            }
        }
        ctx.disableScissor();
        contentTotal = total;

        if (maxScroll > 0) {
            int barH = Math.max(14, (int) (ch * (ch / (float) contentTotal)));
            int barY = cy + (int) ((ch - barH) * (scroll / maxScroll));
            ctx.fill(cx + cw + 3, barY, cx + cw + 5, barY + barH, Hud.alpha(acc, 0xAA));
        }
    }

    // ---------- input ----------
    private boolean inContent(double mx, double my) {
        return mx >= cx && mx < cx + cw + 4 && my >= cy && my < cy + ch;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int[] r = tabRect(i);
            if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) {
                tab = cats[i]; lastTab = tab; scroll = 0; targetScroll = 0;
                return true;
            }
        }
        if (inContent(mx, my)) {
            for (Hit h : hits) {
                if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;
                if (h.setting == null) {
                    if (button == 0) h.module.toggle();
                    else if (button == 1 && !h.module.settings.isEmpty()) h.module.expanded = !h.module.expanded;
                } else if (h.setting instanceof Setting.Slider sl) {
                    if (button == 0) {
                        dragging = sl; dragX = cx + 12; dragW = cw - 22;
                        updateSlider(mx);
                    }
                } else if (h.setting instanceof Setting.Mode md) {
                    md.next(button == 0);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void updateSlider(double mx) {
        if (dragging == null) return;
        double t = Math.max(0, Math.min(1, (mx - dragX) / dragW));
        dragging.set(dragging.min + t * (dragging.max - dragging.min));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        targetScroll -= (float) (v * 20);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Config.save(); }

    @Override
    public boolean shouldPause() { return false; }
}
