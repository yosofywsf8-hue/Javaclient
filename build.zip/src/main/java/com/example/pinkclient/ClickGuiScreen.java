package com.example.pinkclient;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int ROW = 17, SLIDER_H = 21, MODE_H = 16, HEADER = 24, GAP = 8, RADIUS = 7;
    private static final Category[] CATS = Category.values();
    private static final Identifier FONT_ID = Identifier.of("pinkclient", "ui");

    private static final String[] SPARKLE = {"...#...", "...#...", "..###..", "#######", "..###..", "...#...", "...#..."};
    private static final String[] DOTS    = {"##.##.##", "##.##.##"};
    private static final String[] GEAR    = {"#.###.#", ".#####.", "###.###", "###.###", "###.###", ".#####.", "#.###.#"};
    private static final String[][] ICONS = {SPARKLE, DOTS, GEAR};
    private static final String[] CHECK   = {"......#", ".....#.", "#...#..", ".#.#...", "..#...."};
    private static final String[] ARROW_R = {"#..", ".#.", "..#", ".#.", "#.."};
    private static final String[] ARROW_D = {"#...#", ".#.#.", "..#.."};

    private final float[] scroll = new float[3], target = new float[3], curH = new float[3];
    private final int[] total = new int[3];
    private float openAnim;

    private record Hit(int x, int y, int w, int h, int panel, Module module, Setting setting) {}
    private final List<Hit> hits = new ArrayList<>();
    private Setting.Slider dragging;
    private int dragX, dragW;

    public ClickGuiScreen() { super(Text.literal("AKICLIENT")); }

    private Text t(String s, boolean bold) {
        Style st = ModuleManager.FONT.enabled ? Style.EMPTY.withFont(FONT_ID) : Style.EMPTY;
        if (bold) st = st.withBold(true);
        return Text.literal(s).setStyle(st);
    }

    // ---------- geometry ----------
    private int panelW() { return Math.max(72, Math.min(120, (width - 24 - GAP * 2) / 3)); }
    private int maxH() { return Math.min(190, height - 40); }
    private int px(int i) { return (width - (panelW() * 3 + GAP * 2)) / 2 + i * (panelW() + GAP); }
    private int top() { return (height - maxH()) / 2; }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        openAnim += (1f - openAnim) * 0.14f;
        int acc = ModuleManager.accent();
        ctx.fill(0, 0, width, height, Hud.alpha(0x000000, (int) (0x50 * openAnim)));
        hits.clear();

        int pw = panelW(), y0 = top();
        for (int i = 0; i < CATS.length; i++) {
            float a = Math.max(0f, Math.min(1f, openAnim * 1.6f - i * 0.2f));
            int x0 = px(i);
            int wantH = Math.max(70, Math.min(maxH(), HEADER + total[i] + 8));
            curH[i] += (wantH - (curH[i] == 0 ? wantH : curH[i])) * 0.25f;
            if (curH[i] == 0) curH[i] = wantH;
            int ph = Math.round(curH[i]);
            int yy = y0 + (int) ((1f - a) * 18);

            // soft glow, border, body
            for (int g = 4; g >= 1; g--)
                Hud.roundR(ctx, x0 - g, yy - g, x0 + pw + g, yy + ph + g, RADIUS + g, Hud.alpha(acc, (int) (9 * a)));
            Hud.roundR(ctx, x0, yy, x0 + pw, yy + ph, RADIUS, Hud.alpha(0xFFFFFF, (int) (0x26 * a)));
            Hud.roundR(ctx, x0 + 1, yy + 1, x0 + pw - 1, yy + ph - 1, RADIUS - 1, Hud.alpha(0x090B14, (int) (0xE8 * a)));

            // header
            ctx.drawText(tr, t(CATS[i].label, true), x0 + 9, yy + 8, 0xFFFFFFFF, false);
            String[] ic = ICONS[i];
            Hud.icon(ctx, x0 + pw - 10 - ic[0].length(), yy + 9, ic, 0xFFFFFFFF);

            int cx = x0 + 4, cy = yy + HEADER, cw = pw - 8, ch = ph - HEADER - 6;
            float maxScroll = Math.max(0, total[i] - ch);
            target[i] = Math.max(0, Math.min(maxScroll, target[i]));
            scroll[i] += (target[i] - scroll[i]) * 0.3f;

            ctx.enableScissor(cx, cy, cx + cw, cy + ch);
            int y = cy - Math.round(scroll[i]);
            int used = 0;
            for (Module m : ModuleManager.in(CATS[i])) {
                m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.22f;
                boolean hov = mx >= cx && mx < cx + cw && my >= y && my < y + ROW && my >= cy && my < cy + ch;
                if (hov) Hud.roundR(ctx, cx, y, cx + cw, y + ROW, 4, 0x1CFFFFFF);

                int slide = (int) (m.anim * 10);
                int tcol = Hud.lerp(0xFF9EA3B5, 0xFFFFFFFF, m.anim);
                if (!m.toggleable) tcol = 0xFFFFFFFF;
                if (m.anim > 0.15f) Hud.icon(ctx, cx + 5, y + 6, CHECK, Hud.alpha(0xFFFFFF, (int) (255 * m.anim)));
                ctx.drawText(tr, t(m.name, false), cx + 6 + slide, y + 4, tcol, false);

                if (!m.settings.isEmpty()) {
                    String[] ar = m.expanded ? ARROW_D : ARROW_R;
                    Hud.icon(ctx, cx + cw - 9, y + (m.expanded ? 7 : 6), ar, 0xFF8A8FA3);
                }
                hits.add(new Hit(cx, y, cw, ROW, i, m, null));
                y += ROW; used += ROW;

                if (m.expanded) {
                    for (Setting s : m.settings) {
                        if (s instanceof Setting.Slider sl) {
                            Hud.roundR(ctx, cx + 3, y, cx + cw, y + SLIDER_H, 4, 0x40000000);
                            ctx.drawText(tr, t(sl.name, false), cx + 9, y + 3, 0xFFB6BACD, false);
                            Text vt = t(sl.display(), false);
                            ctx.drawText(tr, vt, cx + cw - 6 - tr.getWidth(vt), y + 3, 0xFFFFFFFF, false);
                            int tx = cx + 9, tw = cw - 18, ty = y + 15;
                            Hud.roundR(ctx, tx, ty, tx + tw, ty + 3, 1, 0xFF262938);
                            float f = (float) ((sl.value - sl.min) / (sl.max - sl.min));
                            if (f > 0.02f) Hud.roundR(ctx, tx, ty, tx + Math.max(3, (int) (tw * f)), ty + 3, 1, acc);
                            int kx = tx + (int) (tw * f);
                            Hud.roundR(ctx, kx - 2, ty - 2, kx + 3, ty + 5, 2, 0xFFFFFFFF);
                            hits.add(new Hit(cx + 3, y, cw - 3, SLIDER_H, i, m, sl));
                            y += SLIDER_H; used += SLIDER_H;
                        } else if (s instanceof Setting.Mode md) {
                            Hud.roundR(ctx, cx + 3, y, cx + cw, y + MODE_H, 4, 0x40000000);
                            ctx.drawText(tr, t(md.name, false), cx + 9, y + 4, 0xFFB6BACD, false);
                            Text vt = t(md.get(), false);
                            ctx.drawText(tr, vt, cx + cw - 6 - tr.getWidth(vt), y + 4, acc, false);
                            hits.add(new Hit(cx + 3, y, cw - 3, MODE_H, i, m, md));
                            y += MODE_H; used += MODE_H;
                        }
                    }
                    y += 3; used += 3;
                }
            }
            ctx.disableScissor();
            total[i] = used;

            if (maxScroll > 0) {
                int barH = Math.max(12, (int) (ch * (ch / (float) total[i])));
                int barY = cy + (int) ((ch - barH) * (scroll[i] / maxScroll));
                Hud.roundR(ctx, x0 + pw - 4, barY, x0 + pw - 2, barY + barH, 1, Hud.alpha(acc, 0xAA));
            }
        }

        Text hint = t("Right Shift - close   |   Right click - settings", false);
        ctx.drawText(tr, hint, (width - tr.getWidth(hint)) / 2, y0 + maxH() + 6, 0xFF8A8FA3, false);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int pw = panelW(), y0 = top();
        for (Hit h : hits) {
            int x0 = px(h.panel);
            int ph = Math.round(curH[h.panel]);
            if (my < y0 + HEADER || my >= y0 + ph - 6 || mx < x0 + 4 || mx >= x0 + pw - 4) continue;
            if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;

            if (h.setting == null) {
                if (button == 0) h.module.toggle();
                else if (button == 1 && !h.module.settings.isEmpty()) h.module.expanded = !h.module.expanded;
            } else if (h.setting instanceof Setting.Slider sl) {
                if (button == 0) {
                    dragging = sl; dragX = h.x + 6; dragW = h.w - 15;
                    updateSlider(mx);
                }
            } else if (h.setting instanceof Setting.Mode md) {
                md.next(button == 0);
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void updateSlider(double mx) {
        if (dragging == null) return;
        double t = Math.max(0, Math.min(1, (mx - dragX) / dragW));
        dragging.set(dragging.min + t * (dragging.max - dragging.min));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        for (int i = 0; i < CATS.length; i++) {
            if (mx >= px(i) && mx < px(i) + panelW()) { target[i] -= (float) (v * 20); break; }
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Config.save(); }

    @Override
    public boolean shouldPause() { return false; }
}
