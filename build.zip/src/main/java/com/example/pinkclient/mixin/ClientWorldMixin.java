package com.example.pinkclient.mixin;

import com.example.pinkclient.Hud;
import com.example.pinkclient.ModuleManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void pinkclient$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Object> cir) {
        if (!ModuleManager.SKY.enabled) return;
        int target = Hud.hsv((float) ModuleManager.SKY_HUE.get(), 0.7f, (float) ModuleManager.SKY_BRIGHT.get());
        float tr = ((target >> 16) & 255) / 255f, tg = ((target >> 8) & 255) / 255f, tb = (target & 255) / 255f;
        Object o = cir.getReturnValue();
        if (o instanceof Integer orig) {
            float f = Math.max(0.04f, Math.max((orig >> 16) & 255, Math.max((orig >> 8) & 255, orig & 255)) / 255f);
            int r = (int) (tr * f * 255), g = (int) (tg * f * 255), b = (int) (tb * f * 255);
            cir.setReturnValue(Integer.valueOf((orig & 0xFF000000) | (r << 16) | (g << 8) | b));
        } else if (o instanceof Vec3d v) {
            double f = Math.max(0.04, Math.max(v.x, Math.max(v.y, v.z)));
            cir.setReturnValue(new Vec3d(tr * f, tg * f, tb * f));
        }
    }
}
