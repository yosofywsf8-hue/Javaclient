package com.example.pinkclient;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name, desc;
    public final Category category;
    public boolean enabled;
    public boolean toggleable = true;
    public boolean expanded;
    public float anim;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, String desc, Category category, boolean enabled) {
        this.name = name; this.desc = desc; this.category = category; this.enabled = enabled;
        this.anim = enabled ? 1f : 0f;
    }
    public Module add(Setting s) { settings.add(s); return this; }
    public Module alwaysOn() { toggleable = false; enabled = true; anim = 1f; return this; }
    public void toggle() { if (toggleable) enabled = !enabled; }
}
