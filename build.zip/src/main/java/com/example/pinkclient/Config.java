package com.example.pinkclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("pinkclient-v3.properties");
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ModuleManager.ALL) {
            p.setProperty(m.name + ".enabled", String.valueOf(m.enabled));
            for (Setting s : m.settings) {
                String k = m.name + "." + s.name;
                if (s instanceof Setting.Slider sl) p.setProperty(k, String.valueOf(sl.value));
                else if (s instanceof Setting.Mode md) p.setProperty(k, String.valueOf(md.index));
            }
        }
        try (OutputStream o = Files.newOutputStream(path())) {
            p.store(o, "Pink Client");
        } catch (IOException ignored) {}
    }

    public static void load() {
        Path f = path();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) { return; }
        for (Module m : ModuleManager.ALL) {
            try {
                String en = p.getProperty(m.name + ".enabled");
                if (en != null && m.toggleable) { m.enabled = Boolean.parseBoolean(en); m.anim = m.enabled ? 1f : 0f; }
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v == null) continue;
                    if (s instanceof Setting.Slider sl) sl.set(Double.parseDouble(v));
                    else if (s instanceof Setting.Mode md) md.index = Math.floorMod(Integer.parseInt(v), md.modes.length);
                }
            } catch (Exception ignored) {}
        }
    }
}
