package com.example.pinkclient;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }

    public static class Slider extends Setting {
        public final double min, max;
        public final boolean integer;
        public double value;

        public Slider(String name, double min, double max, double value, boolean integer) {
            super(name);
            this.min = min; this.max = max; this.value = value; this.integer = integer;
        }
        public double get() { return value; }
        public int getInt() { return (int) Math.round(value); }
        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            value = integer ? Math.round(v) : Math.round(v * 100.0) / 100.0;
        }
        public String display() {
            return integer ? String.valueOf((int) value) : String.format("%.2f", value);
        }
    }

    public static class Mode extends Setting {
        public final String[] modes;
        public int index;

        public Mode(String name, int index, String... modes) {
            super(name);
            this.modes = modes; this.index = index;
        }
        public String get() { return modes[index]; }
        public void next(boolean forward) {
            index = (index + (forward ? 1 : modes.length - 1)) % modes.length;
        }
    }
}
