package com.example.pinkclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import java.lang.management.ManagementFactory;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class Hud {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static double cpu;
    private static long lastCpu;

    // ---------- helpers ----------
    public static int alpha(int c, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int hsv(float h, float s, float v) {
        h = (((h % 360) + 360) % 360) / 60f;
        int i = (int) h;
        float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    /** Rectangle with chamfered corners, no overlapping fills (safe with transparency). */
    public static void round(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1 + 1, y1, x2 - 1, y1 + 1, col);
        c.fill(x1, y1 + 1, x2, y2 - 1, col);
        c.fill(x1 + 1, y2 - 1, x2 - 1, y2, col);
    }

    private static double cpuLoad() {
        long now = System.currentTimeMillis();
        if (now - lastCpu > 1000) {
            lastCpu = now;
            try {
                if (ManagementFactory.getOperatingSystemMXBean()
                        instanceof com.sun.management.OperatingSystemMXBean os) {
                    cpu = Math.max(0, os.getCpuLoad()) * 100;
                }
            } catch (Throwable ignored) {}
        }
        return cpu;
    }

    // ---------- main render ----------
    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int acc = ModuleManager.accent();
        long now = System.currentTimeMillis();

        // screen glow
        if (ModuleManager.GLOW.enabled) {
            int a = (int) (0x90 * ModuleManager.GLOW_AMOUNT.get() / 100.0);
            ctx.fillGradient(0, 0, w, h / 4, alpha(acc, a), alpha(acc, 0));
            ctx.fillGradient(0, h - h / 4, w, h, alpha(acc, 0), alpha(acc, a));
        }

        // hit flash
        long dt = now - PinkClient.lastHit;
        if (ModuleManager.HIT_FLASH.enabled && dt < 300) {
            float f = 1f - dt / 300f;
            int a = (int) (f * ModuleManager.FLASH_POWER.get() / 100.0 * 0x80);
            ctx.fill(0, 0, w, h, alpha(acc, a));
        }

        // info bar
        if (ModuleManager.INFO_BAR.enabled) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            String text = LocalTime.now().format(TIME) + "  |  " + ping + " MS  |  "
                    + mc.getCurrentFps() + " FPS  |  " + (int) cpuLoad() + "% CPU";
            int tw = tr.getWidth(text);
            round(ctx, 3, 3, tw + 15, 17, 0xBB140A18);
            ctx.fill(3, 4, 5, 16, acc);
            ctx.drawText(tr, text, 9, 7, 0xFFFFFFFF, true);
        }

        // coordinates
        if (ModuleManager.COORDS.enabled) {
            String c = String.format("XYZ  %.0f  %.0f  %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            int tw = tr.getWidth(c);
            round(ctx, 3, 21, tw + 15, 35, 0xBB140A18);
            ctx.fill(3, 22, 5, 34, acc);
            ctx.drawText(tr, c, 9, 25, 0xFFFFFFFF, true);
        }

        // watermark
        if (ModuleManager.WATERMARK.enabled) {
            String t = "Pink Client";
            int tw = tr.getWidth(t);
            round(ctx, w - tw - 16, 24, w - 3, 38, 0xBB140A18);
            ctx.fill(w - 5, 25, w - 3, 37, acc);
            ctx.drawText(tr, t, w - tw - 10, 28, acc, true);
        }

        // keystrokes
        if (ModuleManager.KEYS.enabled) {
            int bx = 8, by = h - 64;
            key(ctx, tr, "W", mc.options.forwardKey, bx + 19, by, acc);
            key(ctx, tr, "A", mc.options.leftKey, bx, by + 19, acc);
            key(ctx, tr, "S", mc.options.backKey, bx + 19, by + 19, acc);
            key(ctx, tr, "D", mc.options.rightKey, bx + 38, by + 19, acc);
        }

        // armor
        if (ModuleManager.ARMOR.enabled) {
            EquipmentSlot[] slots = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
            int y = h - 84;
            for (EquipmentSlot s : slots) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (st.isEmpty()) continue;
                round(ctx, w - 24, y - 1, w - 6, y + 17, 0x99140A18);
                ctx.drawItem(st, w - 23, y);
                y += 19;
            }
        }

        // target hud
        if (ModuleManager.TARGET.enabled) {
            LivingEntity t = null;
            if (PinkClient.lastTarget != null && PinkClient.lastTarget.isAlive() && now - PinkClient.lastHit < 4000) {
                t = PinkClient.lastTarget;
            } else if (mc.targetedEntity instanceof PlayerEntity pe) {
                t = pe;
            }
            if (t != null) {
                int x = w / 2 + 14, y = h / 2 + 14;
                String name = t.getName().getString();
                int bw = Math.max(90, tr.getWidth(name) + 16);
                round(ctx, x, y, x + bw, y + 28, 0xCC140A18);
                ctx.fill(x, y + 1, x + 2, y + 27, acc);
                ctx.drawText(tr, name, x + 7, y + 4, 0xFFFFFFFF, true);
                float hp = Math.max(0, Math.min(1, t.getHealth() / t.getMaxHealth()));
                ctx.fill(x + 7, y + 18, x + bw - 6, y + 22, 0xFF3A2640);
                ctx.fill(x + 7, y + 18, x + 7 + (int) ((bw - 13) * hp), y + 22, lerp(0xFFFF4466, acc, hp));
            }
        }

        // hit marker
        if (ModuleManager.HIT_MARKER.enabled && dt < 350) {
            int a = (int) ((1f - dt / 350f) * 255);
            int cx = w / 2, cy = h / 2, col = alpha(0xFFFFFF, a);
            for (int i = 4; i <= 8; i++) {
                ctx.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, col);
                ctx.fill(cx - i - 1, cy + i, cx - i, cy + i + 1, col);
                ctx.fill(cx + i, cy - i - 1, cx + i + 1, cy - i, col);
                ctx.fill(cx - i - 1, cy - i - 1, cx - i, cy - i, col);
            }
        }
    }

    private static void key(DrawContext ctx, TextRenderer tr, String label, KeyBinding kb, int x, int y, int acc) {
        boolean down = kb.isPressed();
        round(ctx, x, y, x + 17, y + 17, down ? alpha(acc, 0xCC) : 0xAA140A18);
        ctx.drawCenteredTextWithShadow(tr, label, x + 9, y + 5, 0xFFFFFFFF);
    }
}
