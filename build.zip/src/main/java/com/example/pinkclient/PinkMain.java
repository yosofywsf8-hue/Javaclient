package com.example.pinkclient;

import net.fabricmc.api.ModInitializer;

public class PinkMain implements ModInitializer {
    @Override
    public void onInitialize() { ParticleRegistry.register(); }
}
