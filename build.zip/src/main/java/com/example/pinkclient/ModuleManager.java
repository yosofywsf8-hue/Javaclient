package com.example.pinkclient;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    // ---- settings ----
    public static final Setting.Mode   PRESET      = new Setting.Mode("Preset", 0, "Blue", "Pink", "Purple", "Mint", "Custom");
    public static final Setting.Slider ACCENT_HUE  = new Setting.Slider("Custom Hue", 0, 360, 205, true);
    public static final Setting.Mode   RAINBOW     = new Setting.Mode("Rainbow", 0, "Off", "On");
    public static final Setting.Slider SKY_HUE     = new Setting.Slider("Hue", 0, 360, 208, true);
    public static final Setting.Slider SKY_BRIGHT  = new Setting.Slider("Brightness", 0.3, 1.0, 0.95, false);
    public static final Setting.Slider GLOW_AMOUNT = new Setting.Slider("Strength", 0, 100, 35, true);
    public static final Setting.Slider P_DENSITY   = new Setting.Slider("Density", 1, 10, 6, true);
    public static final Setting.Mode   P_TYPE      = new Setting.Mode("Type", 0, "Stars", "Cherry", "Snow", "End Rod");
    public static final Setting.Mode   H_TYPE      = new Setting.Mode("Style", 0, "Crystal + X", "Crystal", "X Marks", "Hearts", "Crit", "Electric");
    public static final Setting.Slider H_AMOUNT    = new Setting.Slider("Amount", 3, 40, 14, true);
    public static final Setting.Slider FLASH_POWER = new Setting.Slider("Intensity", 10, 100, 45, true);

    // ---- Visuals ----
    public static final Module SKY = new Module("Custom Sky", "Recolors the sky", Category.VISUALS, true)
            .add(SKY_HUE).add(SKY_BRIGHT);
    public static final Module GLOW = new Module("Screen Glow", "Glow on screen edges", Category.VISUALS, true)
            .add(GLOW_AMOUNT);
    public static final Module PARTICLES = new Module("Ambient Particles", "Floating particles", Category.VISUALS, true)
            .add(P_TYPE).add(P_DENSITY);
    public static final Module HIT_PARTICLES = new Module("Hit Particles", "Burst when you hit a player", Category.VISUALS, true)
            .add(H_TYPE).add(H_AMOUNT);
    public static final Module HIT_FLASH = new Module("Hit Flash", "Screen flash on hit", Category.VISUALS, true)
            .add(FLASH_POWER);
    public static final Module HIT_MARKER = new Module("Hit Marker", "X at crosshair on hit", Category.VISUALS, true);

    // ---- Interface ----
    public static final Module INFO_BAR  = new Module("Info Bar", "Time, ping, FPS, CPU", Category.INTERFACE, true);
    public static final Module COORDS    = new Module("Coordinates", "Your XYZ", Category.INTERFACE, true);
    public static final Module EFFECTS   = new Module("Effects HUD", "Active potion effects", Category.INTERFACE, true);
    public static final Module KEYS      = new Module("Keystrokes", "WASD display", Category.INTERFACE, true);
    public static final Module ARMOR     = new Module("Armor HUD", "Worn armor", Category.INTERFACE, true);
    public static final Module TARGET    = new Module("Target HUD", "Name and health of target", Category.INTERFACE, true);
    public static final Module WATERMARK = new Module("Watermark", "Client name", Category.INTERFACE, true);

    // ---- Client ----
    public static final Module ACCENT = new Module("Accent Color", "Main color of the client", Category.CLIENT, true)
            .add(PRESET).add(ACCENT_HUE).add(RAINBOW).alwaysOn();

    public static final List<Module> ALL = List.of(
            SKY, GLOW, PARTICLES, HIT_PARTICLES, HIT_FLASH, HIT_MARKER,
            INFO_BAR, COORDS, EFFECTS, KEYS, ARMOR, TARGET, WATERMARK,
            ACCENT);

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static int accent() {
        float hue;
        if (RAINBOW.index == 1) hue = System.currentTimeMillis() / 20 % 360;
        else {
            switch (PRESET.index) {
                case 0 -> hue = 205;
                case 1 -> hue = 330;
                case 2 -> hue = 270;
                case 3 -> hue = 160;
                default -> hue = (float) ACCENT_HUE.get();
            }
        }
        return Hud.hsv(hue, 0.6f, 1f);
    }
}
