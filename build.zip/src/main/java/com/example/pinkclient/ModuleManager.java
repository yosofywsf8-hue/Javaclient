package com.example.pinkclient;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    // ---- settings used elsewhere ----
    public static final Setting.Slider ACCENT_HUE  = new Setting.Slider("Hue", 0, 360, 330, true);
    public static final Setting.Mode   RAINBOW     = new Setting.Mode("Rainbow", 0, "Off", "On");
    public static final Setting.Slider SKY_HUE     = new Setting.Slider("Hue", 0, 360, 320, true);
    public static final Setting.Slider SKY_BRIGHT  = new Setting.Slider("Brightness", 0.3, 1.0, 0.9, false);
    public static final Setting.Slider GLOW_AMOUNT = new Setting.Slider("Strength", 0, 100, 40, true);
    public static final Setting.Slider P_DENSITY   = new Setting.Slider("Density", 1, 10, 5, true);
    public static final Setting.Mode   P_TYPE      = new Setting.Mode("Type", 0, "Cherry", "End Rod");
    public static final Setting.Mode   H_TYPE      = new Setting.Mode("Particle", 0, "Hearts", "Crit", "End Rod", "Cherry", "Totem");
    public static final Setting.Slider H_AMOUNT    = new Setting.Slider("Amount", 3, 40, 14, true);
    public static final Setting.Slider FLASH_POWER = new Setting.Slider("Intensity", 10, 100, 50, true);

    // ---- HUD ----
    public static final Module INFO_BAR  = new Module("Info Bar", "Time, ping, FPS, CPU", Category.HUD, true);
    public static final Module COORDS    = new Module("Coordinates", "Shows your XYZ", Category.HUD, true);
    public static final Module KEYS      = new Module("Keystrokes", "WASD display", Category.HUD, true);
    public static final Module ARMOR     = new Module("Armor HUD", "Worn armor on screen", Category.HUD, true);
    public static final Module TARGET    = new Module("Target HUD", "Name and health of target", Category.HUD, true);
    public static final Module WATERMARK = new Module("Watermark", "Client name", Category.HUD, true);

    // ---- World ----
    public static final Module SKY       = new Module("Custom Sky", "Recolors the sky", Category.WORLD, true)
            .add(SKY_HUE).add(SKY_BRIGHT);
    public static final Module GLOW      = new Module("Screen Glow", "Soft glow on screen edges", Category.WORLD, true)
            .add(GLOW_AMOUNT);
    public static final Module PARTICLES = new Module("Ambient Particles", "Floating particles around you", Category.WORLD, true)
            .add(P_TYPE).add(P_DENSITY);

    // ---- Hit effects ----
    public static final Module HIT_PARTICLES = new Module("Hit Particles", "Particles when you hit a player", Category.COMBAT, true)
            .add(H_TYPE).add(H_AMOUNT);
    public static final Module HIT_FLASH  = new Module("Hit Flash", "Screen flash on hit", Category.COMBAT, true)
            .add(FLASH_POWER);
    public static final Module HIT_MARKER = new Module("Hit Marker", "X at crosshair on hit", Category.COMBAT, true);

    // ---- Theme ----
    public static final Module ACCENT = new Module("Accent Color", "Main color of the client", Category.THEME, true)
            .add(ACCENT_HUE).add(RAINBOW).alwaysOn();

    public static final List<Module> ALL = List.of(
            INFO_BAR, COORDS, KEYS, ARMOR, TARGET, WATERMARK,
            SKY, GLOW, PARTICLES,
            HIT_PARTICLES, HIT_FLASH, HIT_MARKER,
            ACCENT);

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static int accent() {
        float hue = RAINBOW.index == 1
                ? (System.currentTimeMillis() / 20 % 360)
                : (float) ACCENT_HUE.get();
        return Hud.hsv(hue, 0.55f, 1f);
    }
}
