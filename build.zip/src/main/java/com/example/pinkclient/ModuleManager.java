package com.example.pinkclient;

import java.util.List;

public class ModuleManager {
    public static final Module INFO_BAR  = new Module("Info Bar", true);
    public static final Module FPS_BIG   = new Module("FPS Counter", true);
    public static final Module GLOW      = new Module("Pink Glow", true);
    public static final Module WATERMARK = new Module("Watermark", true);

    public static final List<Module> ALL = List.of(INFO_BAR, FPS_BIG, GLOW, WATERMARK);
}
